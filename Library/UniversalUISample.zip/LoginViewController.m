//
//  LoginViewController.m
//  ProcedureSync
//
//  Created by luongnguyen on 10/28/14.
//  Copyright (c) 2014 appiphany. All rights reserved.
//

#import "PDFWebView.h"
#import "LoginViewController.h"

@interface LoginViewController (Private)

- (void) refreshContainerLayout;

- (void) scrollToCurrentKeyboardResponderWithAnimation:(BOOL)animated;

@end

@implementation LoginViewController

#pragma mark INIT
- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    NSString* nibName = @"LoginViewController~iphone";
    if ([LibUtil checkIfiPad])
    {
        nibName = @"LoginViewController~ipad";
    }
    
    self = [super initWithNibName:nibName bundle:nil];
    
    if (self)
    {
    }
    return self;
}

- (void)viewDidLoad {
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onUIKeyboardWillShowNotification:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onUIKeyboardWillHideNotification:) name:UIKeyboardWillHideNotification object:nil];
    
    [super viewDidLoad];
    
    self.scrollContainer.delegate = self;

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    [self refreshContainerLayout];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void) updateViewWithNewOrientation:(UIInterfaceOrientation)newOrientation iPhoneStyle:(BOOL)is
{
    if (!self.isViewReady)
    {
        [NSTimer timerWithTimeout:0.01 andBlock:^(NSTimer * tmr) {
            [self updateViewWithNewOrientation:newOrientation iPhoneStyle:is];
        }];
        return;
    }
    
    //a strict to make rotation user-feel better
    float keep = keyboardHeight;
    
    keyboardHeight = 0;
    [self refreshContainerLayout];
    
    [NSTimer timerWithTimeout:0.3 andBlock:^(NSTimer* tmr) {
        keyboardHeight = keep;
        [self refreshContainerLayout];
    }];
}

#pragma mark MAIN

#pragma mark PRIVATE
- (void) refreshContainerLayout
{
    NLog(@"REFRESH CONTAINER LAYOUT");
    
    [self.scrollContainer setWidth:self.view.bounds.size.width];
    [self.scrollContainer setHeight:self.view.bounds.size.height-keyboardHeight];

    [self.view layoutSubviews];
    
    cstrViewWidth.constant = self.view.bounds.size.width;
    cstrViewHeight.constant = self.view.bounds.size.height;
    [self.scrollContentView updateConstraintsIfNeeded];
    
    self.scrollContainer.contentSize = self.scrollContentView.frame.size;    
    [self scrollToCurrentKeyboardResponderWithAnimation:NO];
}

- (void) scrollToCurrentKeyboardResponderWithAnimation:(BOOL)animated
{
    if (keyboardHeight > 0)
    {
        UIView* target = nil;
        if ([txtEmail isFirstResponder]) target = btLogin;
        else if ([txtPassword isFirstResponder]) target = btLogin;
        
        if (target && target.frame.origin.y+target.frame.size.height > target.superview.frame.size.height-keyboardHeight)
        {
            float off = (target.frame.origin.y+target.frame.size.height+(20)) - (target.superview.frame.size.height-keyboardHeight);
            
            if (!animated)
            {
                [self.scrollContainer setContentOffset:CGPointMake(0, off)];
            }
            else
            {
//                [NSTimer timerWithTimeout:0.01 andBlock:^(NSTimer* tmr) {
                    [UIView animateWithDuration:0.25 animations:^{
                        [self.scrollContainer setContentOffset:CGPointMake(0, off)];
                    }];
//                }];
            }
        }
    }

}

#pragma mark UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y < 0)
    {
        if (keyboardHeight > 0)
        {
            [self.view endEditing:YES];
        }
    }
}

#pragma mark SELECTORS
- (void) onUIKeyboardWillShowNotification:(NSNotification*)notif
{
    NSValue* value = [notif.userInfo objectForKey:UIKeyboardFrameBeginUserInfoKey];
    CGRect rc = [value CGRectValue];
    
    keyboardHeight = MIN(rc.size.height,rc.size.width);
    [self scrollToCurrentKeyboardResponderWithAnimation:YES];

    [ROOT.view setEnableUI:NO];
    [NSTimer timerWithTimeout:0.3 andBlock:^(NSTimer* tmr) {
        [ROOT.view setEnableUI:YES];
        [self refreshContainerLayout];
    }];
}

- (void) onUIKeyboardWillHideNotification:(NSNotification*)notif
{
//    NSValue* value = [notif.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
//    CGRect rc = [value CGRectValue];
    [self.scrollContainer setScrollEnabled:NO];
    
    keyboardHeight = 0;
    [self refreshContainerLayout];
    
    [self.scrollContainer setScrollEnabled:YES];
    
//    [self scrollToCurrentKeyboardResponderWithAnimation:YES];
//    
//    [ROOT.view setEnableUI:NO];
//    [NSTimer timerWithTimeout:0.3 andBlock:^(NSTimer* tmr) {
//        [ROOT.view setEnableUI:YES];
//        [self refreshContainerLayout];
//    }];
}
@end
