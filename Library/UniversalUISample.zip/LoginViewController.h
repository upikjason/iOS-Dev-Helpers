//
//  LoginViewController.h
//  ProcedureSync
//
//  Created by luongnguyen on 10/28/14.
//  Copyright (c) 2014 appiphany. All rights reserved.
//

#import "BaseViewController.h"

@interface LoginViewController : BaseViewController<UIScrollViewDelegate>
{
    IBOutlet NSLayoutConstraint* cstrViewWidth;
    IBOutlet NSLayoutConstraint* cstrViewHeight;
    float keyboardHeight;
    
    IBOutlet UITextField* txtEmail;
    IBOutlet UITextField* txtPassword;
    IBOutlet UIButton* btLogin;
}

#pragma mark MAIN
@end
